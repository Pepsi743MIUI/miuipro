# ARM SCRIPT Reveal/Amplio Mod
# by Ursaga
if [ "`grep ro.product.name=tetra /system/build.prop`" ]; 
	then
	/sbin/cp -fr /tmp/AndroidWear/. /system

	else
	/sbin/cp -fr /tmp/Android/. /system
fi

# general arm installation
/sbin/cp -fr /tmp/data/. /data
/sbin/cp -fr /tmp/DTS/. /system

# permissions fix													
chmod -R 0755 /system/bin
chmod -R 0755 /system/vendor/bin
chmod -R 0755 /system/su.d
chmod -R 0755 /system/etc/init.d
