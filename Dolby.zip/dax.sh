#!/sbin/sh


sed -i '/^libraries {/ a \
  dax {\
    path /system/lib/soundfx/libswdax.so\
  }' /system/etc/audio_effects.conf
sed -i '/^effects {/ a \
  dax {\
    library dax\
    uuid 9d4921da-8225-4f29-aefa-6e6f69726861\
  }' /system/etc/audio_effects.conf
sed -i '/^libraries {/ a \
  dax {\
    path /system/lib/soundfx/libswdax.so\
  }' /system/vendor/etc/audio_effects.conf
sed -i '/^effects {/ a \
  dax {\
    library dax\
    uuid 9d4921da-8225-4f29-aefa-6e6f69726861\
  }' /system/vendor/etc/audio_effects.conf  
sed -i '/deep_buffer {/,/}/s/^/#/' /system/etc/audio_policy.conf  
